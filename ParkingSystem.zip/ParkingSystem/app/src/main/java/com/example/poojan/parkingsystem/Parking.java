package com.example.poojan.parkingsystem;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Parking extends AppCompatActivity {
    Button button;
    Button button1;
    EditText Name;
    EditText stdid;
    EditText rid,spot,hours;
    TextView txt;
    List<String> spots=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        addOnClickListener();
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
public void addOnClickListener(){
        button=(Button)findViewById(R.id.button3);
    button1=(Button)findViewById(R.id.button6);
    Name=(EditText)findViewById(R.id.editText20);
    stdid=(EditText)findViewById(R.id.editText21);
    rid=(EditText)findViewById(R.id.editText22);
    spot=(EditText)findViewById(R.id.editText23);
    hours=(EditText)findViewById(R.id.editText24);
    txt=(TextView)findViewById(R.id.textView16);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent=new Intent(Parking.this,Parkingspot.class);
                startActivity(intent);
            }
        });
         button.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if(Name.getText().toString().isEmpty()||stdid.getText().toString().isEmpty()||rid.getText().toString().isEmpty()||spot.getText().toString().isEmpty()||hours.getText().toString().isEmpty()){
                     txt.setTextColor(Color.RED);
                     txt.setText("Fill all the details");
                 }
                 else{
                     if(spots.contains(spot.getText().toString())){
                         txt.setTextColor(Color.RED);
                         txt.setText("Spot already taken");
                     }
                     else{
                         spots.add(spot.getText().toString());
                         txt.setTextColor(Color.GREEN);
                         txt.setText("Parking Confirmed");
                     }
                 }

             }
         });

}
}
