package com.example.poojan.parkingsystem;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Parkigntwo extends AppCompatActivity {
Button button;
Button button1;
EditText Name;
EditText stdid;
EditText rid,spot,hours;
TextView txt;
List<String> spots=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parkigntwo);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        addOnClickListener();
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    public void addOnClickListener()
    {button=(Button)findViewById(R.id.button2000);
        button1=(Button)findViewById(R.id.button1001);
        Name=(EditText)findViewById(R.id.Name1);
        stdid=(EditText)findViewById(R.id.StdId1);
        rid=(EditText)findViewById(R.id.RegNo1);
        spot=(EditText)findViewById(R.id.Spot1);
        hours=(EditText)findViewById(R.id.Hours1);
        txt=(TextView)findViewById(R.id.message);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent=new Intent(Parkigntwo.this,Activaparking.class);
                startActivity(intent);
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Name.getText().toString().isEmpty()||stdid.getText().toString().isEmpty()||rid.getText().toString().isEmpty()||spot.getText().toString().isEmpty()||hours.getText().toString().isEmpty()){
                    txt.setTextColor(Color.RED);
                    txt.setText("Fill all the details");
                }
                else{
                    if(spots.contains(spot.getText().toString())){
                        txt.setTextColor(Color.RED);
                        txt.setText("Spot already taken");
                    }
                    else{
                        spots.add(spot.getText().toString());
                        txt.setTextColor(Color.GREEN);
                        txt.setText("Parking Confirmed");
                        }
                }
            }
        });
    }

}
